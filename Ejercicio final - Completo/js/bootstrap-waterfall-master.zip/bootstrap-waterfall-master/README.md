[![996.icu](https://img.shields.io/badge/link-996.icu-red.svg)](https://996.icu)
[![LICENSE](https://img.shields.io/badge/license-Anti%20996-blue.svg)](https://github.com/996icu/996.ICU/blob/master/LICENSE)

# Bootstrap-waterfall
> Waterfall the world beauty.

Bootstrap-waterfall renders your images like [Pinterest](https://www.pinterest.com/).  
Zero configuration, just `$('.waterfall').waterfall()`   
Fork it and [CONTRIBUTING](https://github.com/Mystist/bootstrap-waterfall/blob/master/CONTRIBUTING.md), it's fairly simple.

#### Why named as bootstrap?
- We love bootstrap.
- The codebase is from bootstrap team.
- Support responsive layout, such as bootstrap.
